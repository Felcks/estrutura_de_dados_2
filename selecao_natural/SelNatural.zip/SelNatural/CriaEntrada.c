#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{
	FILE *out;
	if ((out = fopen("entrada.dat","w+b"))==NULL)
	{
		printf("Nao foi possivel abir o arquivo\n");
		exit(1);
	}
	else{
		int vEntrada[54] = {29,14,76,75,59,6,7,74,48,46,10,18,56,20,26,4,21,65,22,49,11,16,8,15,5,19,50,55,25,66,57,77,12,30,17,9,54,78,43,38,51,32,58,13,73,79,27,1,3,60,36,47,31,80};
		for (int i = 0; i < 54; i++)
		{
			fwrite(&vEntrada[i], sizeof(int), 1, out);
		}

	}
	rewind(out);
	int aux;
	for (int i = 0; feof(out); i)
		{
			fread(&aux, sizeof(int), 1, out);
			printf("%d\n",aux);
		}

	fclose(out);
	return 0;
}
