#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{
	FILE *input;
	printf("_res0_\n");
	if ((input = fopen("part0.dat","rb"))==NULL)
	{
		printf("Nao foi possivel abir o arquivo\n");
		exit(1);
	}
	rewind(input);
	int aux;
	fread(&aux, sizeof(int), 1, input);
	while(feof(input)==0){
		printf("%d\n",aux);
		fread(&aux, sizeof(int), 1, input);
	}

	fclose(input);

	printf("_res1_\n");
	if ((input = fopen("part1.dat","rb"))==NULL)
	{
		printf("Nao foi possivel abir o arquivo\n");
		exit(1);
	}
	rewind(input);
	fread(&aux, sizeof(int), 1, input);
	while(feof(input)==0){
		printf("%d\n",aux);
		fread(&aux, sizeof(int), 1, input);
	}

	fclose(input);

	if ((input = fopen("part2.dat","rb"))==NULL)
	{
		printf("Nao foi possivel abir o arquivo\n");
		exit(1);
	}
	rewind(input);
	printf("_res2_\n");
	fread(&aux, sizeof(int), 1, input);
	while(feof(input)==0){
		printf("%d\n",aux);
		fread(&aux, sizeof(int), 1, input);
	}
	fclose(input);
	if ((input = fopen("part3.dat","rb"))==NULL)
	{
		printf("Nao foi possivel abir o arquivo\n");
		exit(1);
	}
	rewind(input);
	printf("_res3_\n");
	fread(&aux, sizeof(int), 1, input);
	while(feof(input)==0){
		printf("%d\n",aux);
		fread(&aux, sizeof(int), 1, input);
	}
	fclose(input);
	if ((input = fopen("part4.dat","rb"))==NULL)
	{
		printf("Nao foi possivel abir o arquivo\n");
		exit(1);
	}
	rewind(input);
	printf("_res4_\n");
	fread(&aux, sizeof(int), 1, input);
	while(feof(input)==0){
		printf("%d\n",aux);
		fread(&aux, sizeof(int), 1, input);
	}
	fclose(input);
	return 0;
}
